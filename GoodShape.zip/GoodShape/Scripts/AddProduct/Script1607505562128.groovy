import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.testobject.TestObject

WebUI.openBrowser('')

WebUI.navigateToUrl('https://testappnovation.wixsite.com/goodshape/shop')

WebUI.delay(5)

//Add Product 1 
WebUI.click(findTestObject('Object Repository/Page_Shop  Good Shape/img_R 7,50__17TsC _3dS0Z _2lsYE'))

WebUI.delay(5)

WebUI.click(findTestObject('Object Repository/Page_Im a product  Good Shape/span_Add to Cart'))


WebUI.navigateToUrl('https://testappnovation.wixsite.com/goodshape/shop')

WebUI.delay(5)

WebUI.click(findTestObject('Object Repository/Page_Im a product  Good Shape/p_Shop'))

WebUI.delay(5)

//Add Product 2
WebUI.click(findTestObject('Object Repository/Page_Shop  Good Shape/img_R 40,00__17TsC _3dS0Z _2lsYE'))

WebUI.delay(5)

WebUI.click(findTestObject('Object Repository/Page_Im a product  Good Shape/span_Add to Cart'))


WebUI.navigateToUrl('https://testappnovation.wixsite.com/goodshape/shop')

WebUI.delay(5)

//Add Product 3
WebUI.click(findTestObject('Object Repository/Page_Shop  Good Shape/img_R 85,00__17TsC _3dS0Z _2lsYE'))

WebUI.delay(5)

WebUI.click(findTestObject('Object Repository/Page_Im a product  Good Shape/span_Add to Cart'))

WebUI.navigateToUrl('https://testappnovation.wixsite.com/goodshape/shop')

WebUI.delay(5)

//Navigate To Cart
WebUI.click(findTestObject('Object Repository/Page_Im a product  Good Shape/text_3'))

WebUI.click(findTestObject('Object Repository/Page_Im a product  Good Shape/a_View Cart'))

//Remove an Item from Cart
WebUI.delay(10)

WebUI.click(findTestObject('Object Repository/Page_Cart  Good Shape/svg'))

WebUI.click(findTestObject('Object Repository/Page_Cart  Good Shape/button_Checkout'))

WebUI.click(findTestObject('Object Repository/Page_Cart  Good Shape/button_Got It'))

WebUI.closeBrowser()
