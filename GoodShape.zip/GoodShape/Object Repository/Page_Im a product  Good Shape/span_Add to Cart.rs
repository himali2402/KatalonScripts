<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Add to Cart</name>
   <tag></tag>
   <elementGuidId>0badcdae-49f4-47ed-a7d6-4f5a1950376c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='TPAMultiSection_kia8g4ye']/div/div/article/div[2]/section[2]/div[4]/div[2]/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.buttonnext3764705582__root.Focusable438576605__root.Focusable438576605--focus.Button561866578__root.Button561866578---priority-5-basic.Button561866578---size-6-medium.Button561866578--fullWidth.StatesButton1317850196__root.AddToCartButton3061789056__addToCartButton > span.buttonnext3764705582__content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>buttonnext3764705582__content</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add to Cart</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;TPAMultiSection_kia8g4ye&quot;)/div[@class=&quot;TPAMultiSection_kia8g4ye&quot;]/div[@class=&quot;_1TImB layout__simple isDesktop&quot;]/article[@class=&quot;_1t5Mn&quot;]/div[@class=&quot;_2E_da _3Q2tO&quot;]/section[@class=&quot;_3GNyR&quot;]/div[@class=&quot;fggS- cell&quot;]/div[@class=&quot;_3j0qu fggS- cell&quot;]/button[@class=&quot;buttonnext3764705582__root Focusable438576605__root Focusable438576605--focus Button561866578__root Button561866578---priority-5-basic Button561866578---size-6-medium Button561866578--fullWidth StatesButton1317850196__root AddToCartButton3061789056__addToCartButton&quot;]/span[@class=&quot;buttonnext3764705582__content&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='TPAMultiSection_kia8g4ye']/div/div/article/div[2]/section[2]/div[4]/div[2]/button/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quantity'])[1]/following::span[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Color'])[1]/following::span[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscribe Form'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submit'])[1]/preceding::span[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add to Cart']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/button/span</value>
   </webElementXpaths>
</WebElementEntity>
