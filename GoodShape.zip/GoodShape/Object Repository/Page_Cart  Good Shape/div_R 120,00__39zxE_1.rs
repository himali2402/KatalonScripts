<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_R 120,00__39zxE_1</name>
   <tag></tag>
   <elementGuidId>f53d38a2-f194-4e27-bdd3-cae6ff142648</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;root&quot;)/div[1]/div[1]/div[@class=&quot;ltr cZLe8 responsive _1UAmk&quot;]/div[@class=&quot;AUSoa&quot;]/div[1]/div[@class=&quot;_3NwQm&quot;]/div[@class=&quot;_49NEN _1HoSi&quot;]/div[@class=&quot;qtNsu&quot;]/div[@class=&quot;_2_ySV&quot;]/div[2]/section[@class=&quot;Ahf9B&quot;]/div[@class=&quot;_2ZZtv&quot;]/div[@class=&quot;Ogidf&quot;]/div[@class=&quot;_3t87a&quot;]/div[@class=&quot;_3ur41 _1vjgH&quot;]/span[@class=&quot;_3iS3A _13S_f&quot;]/div[@class=&quot;Ssv6i _3GKP6 _26sRI _1boDx&quot;]/div[@class=&quot;_3sBNH&quot;]/div[@class=&quot;_3XjRl&quot;]/div[@class=&quot;_1wTId&quot;]/span[@class=&quot;_1ytDW&quot;]/div[@class=&quot;_3Bvpj&quot;]/div[@class=&quot;_39zxE&quot;][count(. | //*[@ref_element = 'Object Repository/Page_Cart  Good Shape/iframe_Log In_yuKeh_1']) = count(//*[@ref_element = 'Object Repository/Page_Cart  Good Shape/iframe_Log In_yuKeh_1'])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div/div/div/div/div/div/div[2]/section/div/div/div[2]/div[2]/span/div/div/div/div/span/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div._39zxE</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>_39zxE</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[1]/div[1]/div[@class=&quot;ltr cZLe8 responsive _1UAmk&quot;]/div[@class=&quot;AUSoa&quot;]/div[1]/div[@class=&quot;_3NwQm&quot;]/div[@class=&quot;_49NEN _1HoSi&quot;]/div[@class=&quot;qtNsu&quot;]/div[@class=&quot;_2_ySV&quot;]/div[2]/section[@class=&quot;Ahf9B&quot;]/div[@class=&quot;_2ZZtv&quot;]/div[@class=&quot;Ogidf&quot;]/div[@class=&quot;_3t87a&quot;]/div[@class=&quot;_3ur41 _1vjgH&quot;]/span[@class=&quot;_3iS3A _13S_f&quot;]/div[@class=&quot;Ssv6i _3GKP6 _26sRI _1boDx&quot;]/div[@class=&quot;_3sBNH&quot;]/div[@class=&quot;_3XjRl&quot;]/div[@class=&quot;_1wTId&quot;]/span[@class=&quot;_1ytDW&quot;]/div[@class=&quot;_3Bvpj&quot;]/div[@class=&quot;_39zxE&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_Cart  Good Shape/iframe_Log In_yuKeh_1</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div/div/div/div/div/div/div[2]/section/div/div/div[2]/div[2]/span/div/div/div/div/span/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='R$ 120,00'])[1]/following::div[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('I', &quot;'&quot;, 'm a product')])[1]/following::div[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total'])[1]/preceding::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='R$ 240,00'])[1]/preceding::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/div/div/div/div/span/div/div</value>
   </webElementXpaths>
</WebElementEntity>
